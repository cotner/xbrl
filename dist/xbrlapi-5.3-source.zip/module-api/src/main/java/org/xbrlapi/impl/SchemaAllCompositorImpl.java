package org.xbrlapi.impl;

import org.xbrlapi.SchemaAllCompositor;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class SchemaAllCompositorImpl extends SchemaCompositorImpl implements SchemaAllCompositor {

    /**
     * 
     */
    private static final long serialVersionUID = -4123274191036423849L;

}