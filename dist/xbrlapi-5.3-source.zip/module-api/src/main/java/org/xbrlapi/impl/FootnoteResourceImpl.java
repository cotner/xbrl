package org.xbrlapi.impl;

import org.xbrlapi.FootnoteResource;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class FootnoteResourceImpl extends MixedContentResourceImpl implements FootnoteResource {

    /**
     * 
     */
    private static final long serialVersionUID = -8875808422865876140L;
	
}
