package org.xbrlapi;

/**
 * Interface for xsd:choice element fragments.
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public interface SchemaChoiceCompositor extends SchemaCompositor {   
    
}
