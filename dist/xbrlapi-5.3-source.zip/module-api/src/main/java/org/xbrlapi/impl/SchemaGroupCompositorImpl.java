package org.xbrlapi.impl;

import org.xbrlapi.SchemaGroupCompositor;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class SchemaGroupCompositorImpl extends SchemaCompositorImpl implements SchemaGroupCompositor {

    /**
     * 
     */
    private static final long serialVersionUID = -8785959698754119764L;

}