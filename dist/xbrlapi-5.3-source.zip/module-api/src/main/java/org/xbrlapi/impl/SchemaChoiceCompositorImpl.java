package org.xbrlapi.impl;

import org.xbrlapi.SchemaChoiceCompositor;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class SchemaChoiceCompositorImpl extends SchemaCompositorImpl implements SchemaChoiceCompositor {

    /**
     * 
     */
    private static final long serialVersionUID = 1652892957698636841L;

}