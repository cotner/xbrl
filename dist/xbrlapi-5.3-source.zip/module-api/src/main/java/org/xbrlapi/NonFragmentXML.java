package org.xbrlapi;

/**
 * parent interface for non-fragment XML resources in the data store.
 * @author Geoff Shuetrim (geoff@galexy.net)
 *
 */
public abstract interface NonFragmentXML extends XML {
    
}
