package org.xbrlapi.impl;

import org.xbrlapi.ReferencePartDeclaration;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class ReferencePartDeclarationImpl extends ElementDeclarationImpl implements ReferencePartDeclaration {

    /**
     * 
     */
    private static final long serialVersionUID = 2641797838964063144L;
	
}