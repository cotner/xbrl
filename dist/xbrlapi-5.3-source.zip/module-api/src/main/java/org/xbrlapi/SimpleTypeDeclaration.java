package org.xbrlapi;


/**
 * Used for simple type declarations in XML Schemas.
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public interface SimpleTypeDeclaration extends TypeDeclaration {

}
