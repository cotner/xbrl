package org.xbrlapi;

/**
 * Interface for xsd:group element fragments.
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public interface SchemaGroupCompositor extends SchemaCompositor {   
    
}
