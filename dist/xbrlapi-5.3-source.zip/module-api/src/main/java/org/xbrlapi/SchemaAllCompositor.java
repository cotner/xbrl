package org.xbrlapi;

/**
 * Interface for xsd:all element fragments.
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public interface SchemaAllCompositor extends SchemaCompositor {   
    
}
