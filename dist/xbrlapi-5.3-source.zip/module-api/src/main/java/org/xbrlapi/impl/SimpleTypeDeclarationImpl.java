package org.xbrlapi.impl;

import org.xbrlapi.SimpleTypeDeclaration;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class SimpleTypeDeclarationImpl extends TypeDeclarationImpl implements SimpleTypeDeclaration {

    /**
     * 
     */
    private static final long serialVersionUID = 5759072150532607196L;	

}