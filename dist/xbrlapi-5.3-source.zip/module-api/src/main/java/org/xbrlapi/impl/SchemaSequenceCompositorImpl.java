package org.xbrlapi.impl;

import org.xbrlapi.SchemaSequenceCompositor;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class SchemaSequenceCompositorImpl extends SchemaCompositorImpl implements SchemaSequenceCompositor {

    /**
     * 
     */
    private static final long serialVersionUID = -6954914669378049258L;

}