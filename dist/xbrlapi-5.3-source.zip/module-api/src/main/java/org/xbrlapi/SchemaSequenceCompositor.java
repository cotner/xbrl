package org.xbrlapi;

/**
 * Interface for xsd:sequence element fragments.
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public interface SchemaSequenceCompositor extends SchemaCompositor {   
    
}
