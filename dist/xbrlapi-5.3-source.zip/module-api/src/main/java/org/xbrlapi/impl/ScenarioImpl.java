package org.xbrlapi.impl;

import org.xbrlapi.Scenario;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class ScenarioImpl extends OpenContextComponentImpl implements Scenario {

    /**
     * 
     */
    private static final long serialVersionUID = 5647697296385818230L;

}