package org.xbrlapi.xdt;

import org.xbrlapi.Concept;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */
public interface XDTConcept extends Concept {

}
