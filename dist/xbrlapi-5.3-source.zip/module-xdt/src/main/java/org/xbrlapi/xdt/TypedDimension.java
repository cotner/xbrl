package org.xbrlapi.xdt;



/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public interface TypedDimension extends Dimension {   
    
}
