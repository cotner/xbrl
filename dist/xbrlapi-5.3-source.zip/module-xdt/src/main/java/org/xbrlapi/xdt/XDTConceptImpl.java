package org.xbrlapi.xdt;

import org.xbrlapi.impl.ConceptImpl;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class XDTConceptImpl extends ConceptImpl implements XDTConcept {

    /**
     * 
     */
    private static final long serialVersionUID = -7286523220608634863L;

}