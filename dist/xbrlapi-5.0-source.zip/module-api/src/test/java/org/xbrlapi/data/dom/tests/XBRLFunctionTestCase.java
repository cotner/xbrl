package org.xbrlapi.data.dom.tests;

import java.util.List;

import org.xbrlapi.Concept;
import org.xbrlapi.Fact;
import org.xbrlapi.Instance;
import org.xbrlapi.Tuple;
import org.xbrlapi.utilities.XBRLException;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net) 
*/

public class XBRLFunctionTestCase extends BaseTestCase {
	private final String STARTING_POINT_1 = "test.data.small.instance";
	private final String STARTING_POINT_2 = "test.data.tuple.instance";
	
	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public XBRLFunctionTestCase(String arg0) {
		super(arg0);
	}

    public void testGetConcepts() {
        try {
            loader.discover(this.getURI(STARTING_POINT_1));     
            List<Instance> instances = store.<Instance>getXMLResources("Instance");
            for (Instance instance: instances) {
                for (Fact fact: instance.getFacts()) {
                    Concept concept = store.getConcept(fact.getNamespace(),fact.getLocalname());
                    logger.info("Testing concept " + concept.getName() + " " + concept.getTargetNamespace());
                    assertEquals(fact.getLocalname(),concept.getDataRootElement().getAttribute("name"));
                    assertEquals(fact.getNamespace(),concept.getTargetNamespace());
                }
            }
        } catch (XBRLException e) {
            e.printStackTrace();
            fail("Unexpected " + e.getMessage());
        }
    }
    
    public void testGetTuples() {
        try {
            loader.discover(this.getURI(STARTING_POINT_2));
            List<Tuple> tuples = store.getTuples();
            assertTrue(tuples.size() > 0);
        } catch (XBRLException e) {
            e.printStackTrace();
            fail("Unexpected " + e.getMessage());
        }
    }    

}
