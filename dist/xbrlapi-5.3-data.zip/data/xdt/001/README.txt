This folder contains test data relevant to testing 
XBRL explicit dimensions.

There are two explicit dimensions, each of which can take three different values.

There are no default dimension values for the basic instance and taxonomy
but the instance with defaults uses a default value for the first dimension.