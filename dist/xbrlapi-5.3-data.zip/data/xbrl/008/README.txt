This folder contains test data relevant to testing 
period start and end date handling.