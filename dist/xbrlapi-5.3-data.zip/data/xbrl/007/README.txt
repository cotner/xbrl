This folder contains test data relevant to testing 
analysis of an XBRL instances with units of measure followed by tuples
and with documentation elements followed by tuples.
