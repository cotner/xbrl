This folder contains test data relevant to testing relationship persistence
when some of the relationships are broken because locators point to nothing.