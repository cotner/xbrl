This folder contains test data relevant to testing 
analysis of an XBRL instance earliest and latest periods.

The various instance documents show different permutations 
and combinations of what is required.