This folder contains test data relevant to testing 
analysis of simple presentation networks.