This folder contains test data relevant to testing xml:language attribute inheritance
for XLink label resources.