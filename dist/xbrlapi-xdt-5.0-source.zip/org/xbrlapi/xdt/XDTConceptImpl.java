package org.xbrlapi.xdt;

import org.xbrlapi.impl.ConceptImpl;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class XDTConceptImpl extends ConceptImpl implements XDTConcept {

}