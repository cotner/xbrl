This folder contains test data relevant to namespace resolution
in situations where the namespace declaration 
should be in a parent fragment.