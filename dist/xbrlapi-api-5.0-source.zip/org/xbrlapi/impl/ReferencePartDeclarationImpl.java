package org.xbrlapi.impl;

import org.xbrlapi.ReferencePartDeclaration;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class ReferencePartDeclarationImpl extends ElementDeclarationImpl implements ReferencePartDeclaration {
	
}