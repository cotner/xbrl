package org.xbrlapi.impl;

import org.xbrlapi.FootnoteResource;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class FootnoteResourceImpl extends MixedContentResourceImpl implements FootnoteResource {
	
}
