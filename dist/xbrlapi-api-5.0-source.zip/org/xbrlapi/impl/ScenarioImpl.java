package org.xbrlapi.impl;

import org.xbrlapi.Scenario;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class ScenarioImpl extends OpenContextComponentImpl implements Scenario {

}