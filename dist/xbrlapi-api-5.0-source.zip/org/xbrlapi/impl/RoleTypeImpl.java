package org.xbrlapi.impl;

import org.xbrlapi.RoleType;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public class RoleTypeImpl extends CustomTypeImpl implements RoleType {

}
