package org.xbrlapi;

/**
 * @author Geoffrey Shuetrim (geoff@galexy.net)
 */

public interface ReferencePartDeclaration extends ElementDeclaration {

}
