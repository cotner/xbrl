package org.xbrlapi.xlink.handler.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for org.xbrlapi.xlink.handler.tests");
		//$JUnit-BEGIN$

		//$JUnit-END$
		return suite;
	}

}
